package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
import org.springframework.context.ApplicationContext;

@EnableEurekaServer
@SpringBootApplication
public class TestSpringBoot {
	public static void main(String[] args) {
		/*ApplicationContext ctx=*/SpringApplication.run(TestSpringBoot.class, args);
		/*for(String nm:ctx.getBeanDefinitionNames()) {
			System.out.println(nm);
		}*/
	}

}

package com.demo.dao;

import java.util.List;

import com.demo.bean.Employee;

public interface EmployeeDao {

	List<Employee> findAll();

	List<Employee> findByProjId(int projid);

}

package com.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.demo.bean.Employee;

@Repository
public class EmployeeDaoImpl implements EmployeeDao{
	static List<Employee> elist;
	static {
		elist=new ArrayList<>();
		elist.add(new Employee(100,"Rajan",3333,10));
		elist.add(new Employee(100,"Revati",3434,10));
		elist.add(new Employee(100,"Rajasi",2222,11));
		elist.add(new Employee(100,"Rohan",2323,11));
	}
	@Override
	public List<Employee> findAll() {
		return elist;
	}
	@Override
	public List<Employee> findByProjId(int projid) {
		return elist.stream().filter(ob->ob.getProjid()==projid).collect(Collectors.toList());
	}

}

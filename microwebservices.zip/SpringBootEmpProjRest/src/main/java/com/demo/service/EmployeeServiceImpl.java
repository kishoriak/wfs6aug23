package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.demo.bean.Employee;
import com.demo.dao.EmployeeDao;

@Service
public class EmployeeServiceImpl implements EmployeeService{
	@Autowired
	private EmployeeDao employeeDao;

	@Override
	public List<Employee> getAll() {
		return employeeDao.findAll();
	}

	@Override
	public List<Employee> getAllEmpByProjId(int projid) {
		return employeeDao.findByProjId(projid);
	}

}

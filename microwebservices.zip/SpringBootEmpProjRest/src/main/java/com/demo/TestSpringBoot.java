package com.demo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.EnableEurekaClient;
import org.springframework.context.ApplicationContext;

@EnableEurekaClient
@SpringBootApplication
public class TestSpringBoot {
	public static void main(String[] args) {
		/*ApplicationContext ctx=*/SpringApplication.run(TestSpringBoot.class, args);
		/*for(String nm:ctx.getBeanDefinitionNames()) {
			System.out.println(nm);
		}*/
	}

}

package com.demo.dao;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.springframework.stereotype.Repository;

import com.demo.bean.Project;

@Repository
public class ProjectDaoImpl implements ProjectDao{
	static List<Project> plist;
	static {
		plist=new ArrayList<>();
		plist.add(new Project(10,"Inssurance","Pune",2));
		plist.add(new Project(11,"ShareTrading","Pune",2));
	}
	@Override
	public List<Project> findAll() {
		return plist;
	}
	@Override
	public Project getById(int projid) {
		Optional<Project> p=plist.stream().filter(ob->ob.getProjid()==projid).findFirst();
		//return p.orElse(null);
		if(p.isPresent()) {
			return p.get();
		}
		return null;
	}

}

package com.demo.dao;

import java.util.List;

import com.demo.bean.Project;

public interface ProjectDao {

	List<Project> findAll();

	Project getById(int projid);

}

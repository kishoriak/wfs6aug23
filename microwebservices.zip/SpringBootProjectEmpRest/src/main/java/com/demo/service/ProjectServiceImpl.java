package com.demo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.cloud.client.loadbalancer.LoadBalanced;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

import com.demo.bean.Employee;
import com.demo.bean.Project;
import com.demo.bean.ProjectEmployee;
import com.demo.dao.ProjectDao;

@Service
public class ProjectServiceImpl implements ProjectService{
    @Autowired 
	private ProjectDao projectDao;
    
    @Autowired
    private RestTemplate restTemplate;
    
    

	@Override
	public List<Project> getAll() {
		return projectDao.findAll();
	}

	@Override
	public ProjectEmployee getProjectEmployee(int projid) {
		Project p=projectDao.getById(projid);
		//String url="http://localhost:8484/emp/employees/"+projid;
		String url="http://EMPLOYEE-SERVICE/emp/employees/"+projid;
		List<Employee> elist=restTemplate.getForObject(url, List.class);
		return new ProjectEmployee(p,elist);
		
	}
    
}

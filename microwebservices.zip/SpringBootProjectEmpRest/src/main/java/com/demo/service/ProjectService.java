package com.demo.service;

import java.util.List;

import com.demo.bean.Project;
import com.demo.bean.ProjectEmployee;

public interface ProjectService {

	List<Project> getAll();

	ProjectEmployee getProjectEmployee(int projid);

}

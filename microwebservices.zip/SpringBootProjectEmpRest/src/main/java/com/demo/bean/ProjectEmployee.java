package com.demo.bean;

import java.util.List;

public class ProjectEmployee {
	private Project p;
	private List<Employee> elist;
	public ProjectEmployee() {
		super();
	}
	public ProjectEmployee(Project p, List<Employee> elist) {
		super();
		this.p = p;
		this.elist = elist;
	}
	public Project getP() {
		return p;
	}
	public void setP(Project p) {
		this.p = p;
	}
	public List<Employee> getElist() {
		return elist;
	}
	public void setElist(List<Employee> elist) {
		this.elist = elist;
	}
	@Override
	public String toString() {
		return "ProjectEmployee [p=" + p + ", elist=" + elist + "]";
	}
	

}

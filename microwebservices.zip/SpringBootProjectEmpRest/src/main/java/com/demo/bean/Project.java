package com.demo.bean;

public class Project {
      private int projid;
      private String pname,location;
      private int numEmp;
	public Project() {
		super();
	}
	public Project(int projid, String pname, String location, int numEmp) {
		super();
		this.projid = projid;
		this.pname = pname;
		this.location = location;
		this.numEmp = numEmp;
	}
	public int getProjid() {
		return projid;
	}
	public void setProjid(int projid) {
		this.projid = projid;
	}
	public String getPname() {
		return pname;
	}
	public void setPname(String pname) {
		this.pname = pname;
	}
	public String getLocation() {
		return location;
	}
	public void setLocation(String location) {
		this.location = location;
	}
	public int getNumEmp() {
		return numEmp;
	}
	public void setNumEmp(int numEmp) {
		this.numEmp = numEmp;
	}
	@Override
	public String toString() {
		return "Project [projid=" + projid + ", pname=" + pname + ", location=" + location + ", numEmp=" + numEmp + "]";
	}
	@Override
	public int hashCode() {
		return projid;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Project other = (Project) obj;
		if (projid != other.projid)
			return false;
		return true;
	}
      
}

import './Header.css'
const Header=()=>{
    return(
        <div className="myclass">
          <h1> Product Details</h1>
        </div>
    )
}

export default Header;
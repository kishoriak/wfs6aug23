import './Footer.css'
const Footer=()=>{
    return(
        <div className="footer">
          <hr size="2px" color="red" width="100%"></hr> 
          <h4> &copy; Copyrights reseved</h4>
        </div>
    )
}

export default Footer;
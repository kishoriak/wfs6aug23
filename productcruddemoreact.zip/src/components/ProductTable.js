import React,{Component} from 'react';
import ProductService from '../Service/ProductService'
import ProductForm from './ProductForm';
class ProductTable extends React.Component{
    constructor(props){
        super(props);
        console.log("in producttable constructor");
        this.state={
            prodarr:[],
            searcharr:[],
            flag:false
        }

    }
    componentDidMount(){
        console.log("in producttable componentdidmount");
        //let parr=ProductService.getAll();
        this.fetchdata();
        

    }
    fetchdata(){
        ProductService.getAll()
        .then((result)=>{
            console.log(result)
            this.setState({...this.state,prodarr:[...result.data],searcharr:[...result.data]})})
        .catch((err)=>{
            console.log("error occured",err);
        })
    }
    
    componentDidUpdate(prevProps,prevState){
        if(prevState.flag && prevState.flag!=this.state.flag){
            console.log(prevState.flag+"-----"+this.state.flag)
            this.fetchdata();
        }

    }

    render(){
        console.log("render in producttable");
        return(
            <div>
            <button type="button" name="btn" id="add" value="add" onClick={()=>{this.setState({...this.state,flag:true})}}>Add product</button>
            <br></br>
            <input type="text" name="search" id="search"></input>
            <br></br>
                <table border='2'>
                <thead>
                    <tr>
                        <th>Product id</th>
                        <th>Product Name</th>
                        <th>Product Quantity</th>
                        <th>Product Price</th>
                        <th>Operations</th>
                    </tr>
                    </thead>
                    <tbody>
                    {this.state.searcharr.map(prod=><tr key={prod.pid}>
                        <td>{prod.pid}</td>
                        <td>{prod.pname}</td>
                        <td>{prod.price}</td>
                        <td>{prod.qty}</td>
                        <td>
                            <button type="button" name="btn" id="del" value="del">Delete</button>&nbsp;&nbsp;&nbsp;
                            <button type="button" name="btn" id="update" value="update">Update</button>&nbsp;&nbsp;&nbsp;
                            <button type="button" name="btn" id="view" value="view">View</button>
                        </td>
                    </tr>
                    )}
                    </tbody>
                </table>
                <div>
                    {this.state.flag?<ProductForm changeflag={()=>{this.setState({...this.state,flag:false})}}></ProductForm>:""}
                </div>
            </div>
        )
    }

}

export default ProductTable;
import { useState } from "react";
import ProductService from "../Service/ProductService";
const ProductForm=(props)=>{
    let [formdetails,setformdetails]=useState({pid:"",pname:"",qty:"",price:""});

    const handlechange=(event)=>{
        //this will retreive the name and value property from event.target
        //and replace the appropriate property from formdetails 
        //to the value enterd in the textbox   
        // keep the name of textbox and same as property name in the formdetails
        let {name,value}=event.target;
        console.log(name+"---"+value);
        setformdetails({...formdetails,[name]:value})
      }
      let addProduct=()=>{
        if(formdetails.pid=="" || formdetails.pname=="" || formdetails.qty=="" || formdetails.price==""){
            alert("none of the fields can be empty");
            return
        }
        else{
            ProductService.insertProduct(formdetails)
            .then((result)=>{

                setformdetails({pid:"",pname:"",qty:"",price:""});
              props.changeflag(false);
            })
            .catch((err)=>{
                console.log("error occured",err)
            });
            
        }
      }
   return(
    <div>
    <form>
        <label>Product Id</label>
        <input type="text" name="pid" id="pid"
        value={formdetails.pid}
        onChange={handlechange}></input><br></br>
        <label>Product Name</label>
        <input type="text" name="pname" id="pname"
        value={formdetails.pname}
        onChange={handlechange}></input><br></br>
        <label>Product quantity</label>
        <input type="text" name="qty" id="qty"
        value={formdetails.qty}
        onChange={handlechange}></input><br></br>
        <label>Product price</label>
        <input type="text" name="price" id="price"
        value={formdetails.price}
        onChange={handlechange}></input><br></br>
        <button type="button" name="btn" id="btn" value="insert" onClick={addProduct}>
            Insert new Product
        </button>
    </form>
    </div>
   )
}
export default ProductForm;
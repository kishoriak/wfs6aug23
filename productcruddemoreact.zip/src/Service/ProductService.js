import Product from '../Product'
import axios from 'axios';

let baseUrl="http://localhost:9091/products"
class ProductService{
    constructor(){
        /*this.prodarr=[{pid:111,pname:"chair",qty:34,price:4567},
        {pid:112,pname:"table",qty:45,price:5555.78},
        {pid:113,pname:"shelf",qty:56,price:6666.57},
        {pid:114,pname:"shoe rack",qty:57,price:7777},
        {pid:115,pname:"desk",qty:58,price:7888}]*/
        /*this.prodarr=[new Product(111,'chair',34,4567),
        new Product(112,'table',45,5555.78),
        new Product(113,'"shoe rack"',56,5555),
        new Product(114,'desk',35,4444.78)
     ]*/
    }
    //return all products
    getAll(){
       //return this.prodarr;
        return axios.get(baseUrl)
    }
    
    insertProduct(prod){
       //this.prodarr.push(prod);
       return axios.post(baseUrl+"/"+prod.pid,prod,{headers:{"content-type":"application/json"}})
    }

}

export default new ProductService();
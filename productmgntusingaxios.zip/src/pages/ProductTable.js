import React, { Component } from 'react'
import {Trash,PenFill,EyeFill} from 'react-bootstrap-icons';
import ProductService from '../service/ProductService';
import {Link} from 'react-router-dom';

 class ProductTable extends Component {
  constructor(props){
    super(props);
    console.log("in product table constructor function")
    this.state={
        prodarr:[],
        searcharr:[],   //display the filtered array based on searchtext
        searchtext:""
    }
    
  }
  fetchdata(){
    ProductService.getAllProducts()
    .then((result)=>{
       console.log(result.data);
       this.setState({...this.state,prodarr:[...result.data],searcharr:[...result.data]})
    })
    .catch((error)=>{
        console.log(error);
    })
    
  }
  //this method gets executed only once in the lifetime of the component
  //it gets executed in Mounting phase
  //best place for getting data and initializes
  componentDidMount(){
    console.log("in product table componentdidmount function")
    //code for local array
   /* let arr=ProductService.getAllProducts();
      this.setState({...this.state,prodarr:[...arr],searcharr:[...arr]});*/
   this.fetchdata()

  }
  //use it with care
  //it gets called every time if the sate or props changes
  //useEffect(()=>{},[searchtext]) for functional component
  componentDidUpdate(prevProps,prevState){
    //console.log('In component did upadte')
    //all the code inside if statement, otherwise it will go in infinite loop
    if(prevState.searchtext!==this.state.searchtext){
        console.log("prev: "+prevState.searchtext+"----"+"current: "+this.state.searchtext)
        if(this.state.searchtext!==""){
            let newarr=this.state.prodarr.filter(prod=>prod.pname.includes(this.state.searchtext));
            this.setState({...this.state,searcharr:[...newarr]})
        }
        else{
            this.setState({...this.state,searcharr:[...this.state.prodarr]})
        }
    }
   
  }

  componentWillUnmount(){
    console.log("in producttable component will unmount")
  }
  deleteProduct=(pid)=>{
    ProductService.deletebypid(pid)
    .then((result)=>{
        console.log(result);
        this.fetchdata();  

    })
    .catch()
    .finally()
  }

  //pure function--> no changes in the state should be done here
  //do not use set state
  render() {
    console.log("in product table render function")
    return (
      <div className="container">
      <div className="row">
        <div className="col-sm-12 col-md-12">
        <Link to="/form">
          <button type="button" name="btn" id="btn" value="add" className="btn btn-success">Add new product</button>
        </Link>
          <br></br>
          <br></br>
          Search : <input type="text" name="serach" id="search"
          value={this.state.searchtext}
          onChange={(event)=>{this.setState({...this.state,searchtext:event.target.value})}}></input>
          <br></br>
          <br></br>
          <div>
          <table className="table table-striped">
  <thead>
    <tr>
      <th scope="col">Product id</th>
      <th scope="col">Product Name</th>
      <th scope="col">Product qty</th>
      <th scope="col">product price</th>
      <th>Action</th>
    </tr>
  </thead>
  <tbody>
    {this.state.searcharr.map(prod=>(<tr key={prod.pid}>
      <th scope="row">{prod.pid}</th>
      <td>{prod.pname}</td>
      <td>{prod.qty}</td>
      <td>{prod.price}</td>
     
      <td>
        <button type="button" name="btn" id="del" value="del" className="btn btn-danger" onClick={()=>{this.deleteProduct(prod.pid)}}><Trash/> Delete</button>&nbsp;&nbsp;&nbsp;
        <Link to={`/edit/${prod.pid}`} state={{product:prod}}>
        <button type="button" name="btn" id="edit" value="del" className="btn btn-info"><PenFill/> Edit</button>&nbsp;&nbsp;&nbsp;
        </Link>
        <button type="button" name="btn" id="view" value="del" className="btn btn-primary"><EyeFill/> View</button>&nbsp;&nbsp;&nbsp;
      </td>
    </tr>))
    }
  </tbody>
</table>
          </div>

        </div>

      </div>
      
      </div>
    )
  }
}

export default ProductTable;
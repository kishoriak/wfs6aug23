import React from 'react'

import {useState,useEffect} from 'react';
import ProductService from '../service/ProductService';
import {useParams,useLocation,useNavigate} from 'react-router-dom'

const ProductEdit=(props)=>{
  let [formdetails,setformdetails]=useState({pid:"",pname:"",qty:"",price:""})
  let navigate=useNavigate();
  let params=useParams();
  let location=useLocation();
  useEffect(()=>{
    /*let p=ProductService.getById(params.pid);
    setformdetails(p);*/
    setformdetails({...location.state.product})

  },[])
  const handlechange=(event)=>{
    //this will retreive the name and value property from event.target
    //and replace the appropriate property from formdetails 
    //to the value enterd in the textbox   
    // keep the name of textbox and same as property name in the formdetails
    let {name,value}=event.target;
    console.log(name+"---"+value);
    setformdetails({...formdetails,[name]:value})
  }

  //to add data in productservice
  const updateproduct=()=>{
    ProductService.updateproduct(formdetails)
    .then((result)=>{
         //clear the form
         setformdetails({pid:"",pname:"",qty:"",price:""})
        //navigate("/table",state={name:"xxxx",val:12});
        navigate("/table");
    })
    .catch((error)=>{
        console.log(error)

    })
    
  }
  return (
    <div>
         <form>
    <div className="form-group">
      <label htmlFor="pid">Product pid</label>
      <input
        type="text"
        className="form-control"
        id="pid"
        name="pid"
        value={formdetails.pid}
        onChange={handlechange} 
        readOnly
      />
     
    </div>
    <div className="form-group">
      <label htmlFor="pname">Product name</label>
      <input
        type="text"
        className="form-control"
        id="pname"
        name="pname"
        value={formdetails.pname}
        onChange={handlechange}
      />
    </div>
    <div className="form-group">
      <label htmlFor="qty">Product Qty</label>
      <input
        type="text"
        className="form-control"
        id="qty"
        name="qty"
        value={formdetails.qty}
        onChange={handlechange}
      />
    </div>
    <div className="form-group">
      <label htmlFor="price">Product price</label>
      <input
        type="text"
        className="form-control"
        id="price"
        name="price"
        value={formdetails.price}
        onChange={handlechange}
      />
    </div>
    <button type="button" className="btn btn-primary" onClick={updateproduct}>
     Update Product
    </button>
  </form>
    </div>
  )
}
export default ProductEdit;
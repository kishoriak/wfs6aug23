import axios from 'axios';
const baseUrl="http://localhost:8282/products";
class ProductService{
    constructor(){
        this.prodarr=[{pid:111,pname:"chair",qty:34,price:4567},
        {pid:112,pname:"table",qty:45,price:5555.78},
        {pid:113,pname:"shelf",qty:56,price:6666.57},
        {pid:114,pname:"shoe rack",qty:57,price:7777},
        {pid:115,pname:"desk",qty:58,price:7888}]
    }
    getAllProducts(){
        //get request
        //return this.prodarr;
        //read the data
        return axios.get(baseUrl);
    }
    addnewproduct(product){
        //post request
        //this.prodarr.push(product);
        /*{prod:product,
        movie:movie,
         }*/
         //add the data
        return axios.post(baseUrl+"/"+product.pid,product,{headers:{"content-type":"application/json"}})
    }
    deletebypid(pid){
        //deleting the data
        return axios.delete(baseUrl+"/"+pid);
    }
    getById(pid){

     //return this.prodarr.find(prod=>prod.pid===pid)
     //retrieving single object
     return axios.get(baseUrl+"/"+pid)
    }
    updateproduct(product){
        //let pos=this.prodarr.findIndex(prod=>prod.pid===product.pid)
        //this.prodarr[pos]=product;
        //to update the data
        return axios.put(baseUrl+"/"+product.pid,product,{headers:{"content-type":"application/json"}})
    }

}

export default new ProductService();
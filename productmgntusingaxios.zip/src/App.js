import logo from './logo.svg';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import {Route,Routes,Navigate} from 'react-router-dom'
import MainHeaderNavBar from './components/MainHeaderNavBar';
import ProductTable from './pages/ProductTable';
import ProductForm from './pages/ProductForm';
import HomeComponent from './pages/HomeComponent';
import ProductEdit from './pages/ProductEdit';
function App() {
  return (
    <div className="App">
      <MainHeaderNavBar></MainHeaderNavBar>
      <Routes>
         <Route path="/" element={<Navigate replace to="/home"></Navigate>}></Route>
         <Route path="/home" element={<HomeComponent/>}></Route>
         <Route path="/table" element={<ProductTable />}></Route>
         <Route path="/form" element={<ProductForm/>}></Route>
         <Route path="/edit/:pid" element={<ProductEdit></ProductEdit>}></Route>
      </Routes>
    </div>
  );
}

export default App;

import React from 'react'

const ProductForm=()=> {
  return (
    <div>ProductForm</div>
  )
}
export default ProductForm;
import React from 'react'
import {Link,Outlet} from 'react-router-dom'
const ProductTable=()=>{
  return (
    <div>ProductTable
       <ul>
      <Link to="/table/p1">
        <li>Product p1</li>
    </Link> 
    <Link to="/table/p2">
        <li>Product p2</li>
    </Link>
    <Link to="/table/p3">
        <li>Product p3</li>
    </Link>
       </ul>
       <div>
         <Outlet/>
       </div>
    </div>

  )
}
export default ProductTable;
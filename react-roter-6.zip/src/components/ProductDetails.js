import React from 'react'
import { useParams } from 'react-router-dom';

const ProductDetails=()=> {
   let params=useParams(); 
  return (
    <div>ProductDetails {params.pid}</div>
  )
}
export default ProductDetails;
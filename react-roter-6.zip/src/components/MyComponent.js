import React from 'react'

const MyComponent=()=>{
  return (
    <div>MyComponent</div>
  )
}
export default MyComponent;
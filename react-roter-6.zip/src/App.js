import logo from './logo.svg';
import './App.css';
import {Routes,Route,Navigate} from 'react-router-dom'
import ProductDetails from './components/ProductDetails';
import ProductForm from './components/ProductForm';
import MyComponent from './components/MyComponent';
import ProductTable from './components/ProductTable';


function App() {
  return (
    
      <Routes>
         <Route path="/" element={<Navigate replace to="/home"></Navigate>}></Route>
         <Route path="/home" element={<MyComponent/>}></Route>
         <Route path="/table" element={<ProductTable/>}>
             <Route path=":pid" element={<ProductDetails/>}></Route>
         </Route>
         <Route path="/form" element={<ProductForm/>}></Route>
      </Routes>
    
  );
}

export default App;
